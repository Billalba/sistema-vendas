-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20-Out-2025 às 22:39
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `vendas_db_teste`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `documento`, `email`, `telefone`, `endereco`, `created_at`, `updated_at`) VALUES
(1, 'João Silva', '123.456.789-00', 'joao.silva@email.com', '(11) 9999-1111', 'Rua das Flores, 123 - São Paulo/SP', '2025-10-20 19:29:51', '2025-10-20 19:29:51'),
(2, 'Maria Santos', '987.654.321-00', 'maria.santos@email.com', '(11) 9999-2222', 'Av. Paulista, 1000 - São Paulo/SP', '2025-10-20 19:29:51', '2025-10-20 19:29:51'),
(3, 'Pedro Oliveira', '111.222.333-44', 'pedro.oliveira@email.com', '(11) 9999-3333', 'Rua Augusta, 500 - São Paulo/SP', '2025-10-20 19:29:51', '2025-10-20 19:29:51'),
(4, 'Ana Costa', '555.666.777-88', 'ana.costa@email.com', '(11) 9999-4444', 'Alameda Santos, 200 - São Paulo/SP', '2025-10-20 19:29:51', '2025-10-20 19:29:51'),
(5, 'Carlos Souza', '999.888.777-66', 'carlos.souza@email.com', '(11) 9999-5555', 'Rua XV de Novembro, 50 - São Paulo/SP', '2025-10-20 19:29:51', '2025-10-20 19:29:51');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int(11) DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `sku`, `nome`, `descricao`, `preco`, `estoque`, `ativo`, `created_at`, `updated_at`) VALUES
(1, 'NBK-DELL-001', 'Notebook Dell Inspiron 15', 'Notebook Dell Inspiron 15.6\" Intel Core i5 8GB 256GB SSD', '2999.99', 46, 1, '2025-10-20 19:29:51', '2025-10-20 20:14:34'),
(2, 'MS-LOG-002', 'Mouse Logitech MX Master 3', 'Mouse Ergonômico Logitech MX Master 3 Sem Fio', '199.99', 96, 1, '2025-10-20 19:29:51', '2025-10-20 20:14:16'),
(3, 'TEC-MEC-003', 'Teclado Mecânico Redragon', 'Teclado Mecânico Redragon Kumara RGB Switch Blue', '399.99', 74, 1, '2025-10-20 19:29:51', '2025-10-20 20:15:21'),
(4, 'MON-SAM-004', 'Monitor Samsung 24\"', 'Monitor Samsung 24\" LED Full HD 75Hz HDMI VGA', '899.99', 29, 1, '2025-10-20 19:29:51', '2025-10-20 20:09:20'),
(5, 'HP-SONY-005', 'Headphone Sony WH-1000XM4', 'Fone de Ouvido Sony WH-1000XM4 Noise Cancelling', '1299.99', 23, 1, '2025-10-20 19:29:51', '2025-10-20 20:14:01'),
(6, 'WC-LOG-006', 'Webcam Logitech C920', 'Webcam Logitech C920 HD Pro 1080p', '349.99', 59, 1, '2025-10-20 19:29:51', '2025-10-20 20:13:39'),
(7, 'SSD-KNG-007', 'SSD Kingston 1TB NVMe', 'SSD Kingston NV1 1TB M.2 NVMe 2280', '399.99', 77, 1, '2025-10-20 19:29:51', '2025-10-20 20:16:11'),
(8, 'RAM-KNG-008', 'Memória RAM Kingston 16GB', 'Memória RAM Kingston Fury 16GB DDR4 3200MHz', '299.99', 90, 1, '2025-10-20 19:29:51', '2025-10-20 19:29:51'),
(9, 'CAD-GMR-009', 'Cadeira Gamer DXRacer', 'Cadeira Gamer DXRacer Formula Series Preta', '1599.99', 14, 1, '2025-10-20 19:29:51', '2025-10-20 20:09:20'),
(10, 'MP-XL-010', 'Mousepad Speed Type XL', 'Mousepad Speed Type XL 900x400mm Preto', '49.99', 200, 1, '2025-10-20 19:29:51', '2025-10-20 19:29:51');

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `data_hora` datetime DEFAULT current_timestamp(),
  `cliente_id` int(11) NOT NULL,
  `status` enum('aberta','concluida','cancelada') DEFAULT 'aberta',
  `total_bruto` decimal(10,2) DEFAULT 0.00,
  `total_desconto` decimal(10,2) DEFAULT 0.00,
  `total_liquido` decimal(10,2) DEFAULT 0.00,
  `observacoes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `vendas`
--

INSERT INTO `vendas` (`id`, `codigo`, `data_hora`, `cliente_id`, `status`, `total_bruto`, `total_desconto`, `total_liquido`, `observacoes`, `created_at`, `updated_at`) VALUES
(1, 'V1760988706282', '2025-10-20 16:31:46', 4, 'concluida', '1599.99', '111.11', '1488.88', NULL, '2025-10-20 19:31:46', '2025-10-20 19:31:46'),
(2, 'V1760990819073', '2025-10-20 17:06:59', 4, 'concluida', '899.99', '0.00', '899.99', NULL, '2025-10-20 20:06:59', '2025-10-20 20:09:20'),
(3, 'V1760991138862', '2025-10-20 17:12:18', 2, 'concluida', '4499.97', '1000.00', '3499.97', NULL, '2025-10-20 20:12:18', '2025-10-20 20:12:18'),
(4, 'V1760991162760', '2025-10-20 17:12:42', 3, 'concluida', '2999.99', '999.99', '2000.00', NULL, '2025-10-20 20:12:42', '2025-10-20 20:12:42'),
(5, 'V1760991219758', '2025-10-20 17:13:39', 4, 'concluida', '549.98', '0.00', '549.98', NULL, '2025-10-20 20:13:39', '2025-10-20 20:13:39'),
(6, 'V1760991241304', '2025-10-20 17:14:01', 5, 'concluida', '4299.98', '0.00', '4299.98', NULL, '2025-10-20 20:14:01', '2025-10-20 20:14:01'),
(7, 'V1760991255285', '2025-10-20 17:14:15', 1, 'concluida', '199.99', '0.00', '199.99', NULL, '2025-10-20 20:14:15', '2025-10-20 20:14:15'),
(8, 'V1760991256530', '2025-10-20 17:14:16', 1, 'concluida', '199.99', '0.00', '199.99', NULL, '2025-10-20 20:14:16', '2025-10-20 20:14:16'),
(9, 'V1760991273992', '2025-10-20 17:14:34', 2, 'concluida', '2999.99', '0.00', '2999.99', NULL, '2025-10-20 20:14:34', '2025-10-20 20:14:34'),
(10, 'V1760991284682', '2025-10-20 17:14:44', 3, 'cancelada', '399.99', '0.00', '399.99', NULL, '2025-10-20 20:14:44', '2025-10-20 20:15:33'),
(11, 'V1760991306686', '2025-10-20 17:15:06', 1, 'aberta', '399.99', '0.00', '399.99', NULL, '2025-10-20 20:15:06', '2025-10-20 20:15:42'),
(12, 'V1760991321430', '2025-10-20 17:15:21', 5, 'concluida', '399.99', '0.00', '399.99', NULL, '2025-10-20 20:15:21', '2025-10-20 20:15:21'),
(13, 'V1760991371664', '2025-10-20 17:16:11', 5, 'concluida', '399.99', '0.00', '399.99', NULL, '2025-10-20 20:16:11', '2025-10-20 20:16:11');

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda_itens`
--

CREATE TABLE `venda_itens` (
  `id` int(11) NOT NULL,
  `venda_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL CHECK (`quantidade` > 0),
  `preco_unitario` decimal(10,2) NOT NULL,
  `desconto` decimal(10,2) DEFAULT 0.00,
  `subtotal` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `venda_itens`
--

INSERT INTO `venda_itens` (`id`, `venda_id`, `produto_id`, `quantidade`, `preco_unitario`, `desconto`, `subtotal`, `created_at`) VALUES
(1, 1, 9, 1, '1599.99', '111.11', '1488.88', '2025-10-20 19:31:46'),
(3, 2, 4, 1, '899.99', '0.00', '899.99', '2025-10-20 20:09:20'),
(4, 3, 2, 1, '199.99', '0.00', '199.99', '2025-10-20 20:12:18'),
(5, 3, 5, 1, '1299.99', '0.00', '1299.99', '2025-10-20 20:12:18'),
(6, 3, 1, 1, '2999.99', '1000.00', '1999.99', '2025-10-20 20:12:18'),
(7, 4, 1, 1, '2999.99', '999.99', '2000.00', '2025-10-20 20:12:42'),
(8, 5, 6, 1, '349.99', '0.00', '349.99', '2025-10-20 20:13:39'),
(9, 5, 2, 1, '199.99', '0.00', '199.99', '2025-10-20 20:13:39'),
(10, 6, 1, 1, '2999.99', '0.00', '2999.99', '2025-10-20 20:14:01'),
(11, 6, 5, 1, '1299.99', '0.00', '1299.99', '2025-10-20 20:14:01'),
(12, 7, 2, 1, '199.99', '0.00', '199.99', '2025-10-20 20:14:15'),
(13, 8, 2, 1, '199.99', '0.00', '199.99', '2025-10-20 20:14:16'),
(14, 9, 1, 1, '2999.99', '0.00', '2999.99', '2025-10-20 20:14:34'),
(15, 10, 7, 1, '399.99', '0.00', '399.99', '2025-10-20 20:14:44'),
(17, 12, 3, 1, '399.99', '0.00', '399.99', '2025-10-20 20:15:21'),
(18, 11, 7, 1, '399.99', '0.00', '399.99', '2025-10-20 20:15:42'),
(19, 13, 7, 1, '399.99', '0.00', '399.99', '2025-10-20 20:16:11');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `documento` (`documento`),
  ADD KEY `idx_nome` (`nome`),
  ADD KEY `idx_documento` (`documento`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `idx_sku` (`sku`),
  ADD KEY `idx_nome` (`nome`),
  ADD KEY `idx_ativo` (`ativo`);

--
-- Índices para tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_codigo` (`codigo`),
  ADD KEY `idx_data_hora` (`data_hora`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_cliente_id` (`cliente_id`);

--
-- Índices para tabela `venda_itens`
--
ALTER TABLE `venda_itens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_venda_id` (`venda_id`),
  ADD KEY `idx_produto_id` (`produto_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `venda_itens`
--
ALTER TABLE `venda_itens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `vendas`
--
ALTER TABLE `vendas`
  ADD CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Limitadores para a tabela `venda_itens`
--
ALTER TABLE `venda_itens`
  ADD CONSTRAINT `venda_itens_ibfk_1` FOREIGN KEY (`venda_id`) REFERENCES `vendas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `venda_itens_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
