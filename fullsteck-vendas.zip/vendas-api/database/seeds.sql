USE vendas_db_teste;

-- Inserir produtos
INSERT IGNORE INTO produtos (sku, nome, descricao, preco, estoque) VALUES
('NBK-DELL-001', 'Notebook Dell Inspiron 15', 'Notebook Dell Inspiron 15.6" Intel Core i5 8GB 256GB SSD', 2999.99, 50),
('MS-LOG-002', 'Mouse Logitech MX Master 3', 'Mouse Ergonômico Logitech MX Master 3 Sem Fio', 199.99, 100),
('TEC-MEC-003', 'Teclado Mecânico Redragon', 'Teclado Mecânico Redragon Kumara RGB Switch Blue', 399.99, 75),
('MON-SAM-004', 'Monitor Samsung 24"', 'Monitor Samsung 24" LED Full HD 75Hz HDMI VGA', 899.99, 30),
('HP-SONY-005', 'Headphone Sony WH-1000XM4', 'Fone de Ouvido Sony WH-1000XM4 Noise Cancelling', 1299.99, 25),
('WC-LOG-006', 'Webcam Logitech C920', 'Webcam Logitech C920 HD Pro 1080p', 349.99, 60),
('SSD-KNG-007', 'SSD Kingston 1TB NVMe', 'SSD Kingston NV1 1TB M.2 NVMe 2280', 399.99, 80),
('RAM-KNG-008', 'Memória RAM Kingston 16GB', 'Memória RAM Kingston Fury 16GB DDR4 3200MHz', 299.99, 90),
('CAD-GMR-009', 'Cadeira Gamer DXRacer', 'Cadeira Gamer DXRacer Formula Series Preta', 1599.99, 15),
('MP-XL-010', 'Mousepad Speed Type XL', 'Mousepad Speed Type XL 900x400mm Preto', 49.99, 200);

-- Inserir clientes
INSERT IGNORE INTO clientes (nome, documento, email, telefone, endereco) VALUES
('João Silva', '123.456.789-00', 'joao.silva@email.com', '(11) 9999-1111', 'Rua das Flores, 123 - São Paulo/SP'),
('Maria Santos', '987.654.321-00', 'maria.santos@email.com', '(11) 9999-2222', 'Av. Paulista, 1000 - São Paulo/SP'),
('Pedro Oliveira', '111.222.333-44', 'pedro.oliveira@email.com', '(11) 9999-3333', 'Rua Augusta, 500 - São Paulo/SP'),
('Ana Costa', '555.666.777-88', 'ana.costa@email.com', '(11) 9999-4444', 'Alameda Santos, 200 - São Paulo/SP'),
('Carlos Souza', '999.888.777-66', 'carlos.souza@email.com', '(11) 9999-5555', 'Rua XV de Novembro, 50 - São Paulo/SP');