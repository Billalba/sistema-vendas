import { BaseModel } from './BaseModel.js';
import { pool } from '../database/connection.js';

export class Venda extends BaseModel {
  static tableName = 'vendas';

  // Criar venda com itens (usando transaction)
  static async createWithItems(vendaData, items) {
    let connection;
    try {
      connection = await pool.getConnection();
      await connection.beginTransaction();

      // 1. Gerar código único para a venda
      const vendaCode = `V${Date.now()}`;

      // 2. Inserir venda
      const [vendaResult] = await connection.execute(
        `INSERT INTO ${this.tableName} (codigo, cliente_id, status) VALUES (?, ?, ?)`,
        [vendaCode, vendaData.cliente_id, 'concluida']  // ← AGORA CRIA COMO CONCLUÍDA
      );



      const vendaId = vendaResult.insertId;
      let totalBruto = 0;
      let totalDesconto = 0;

      // 3. Inserir itens da venda e calcular totais
      for (const item of items) {
        const subtotal = (item.preco_unitario * item.quantidade) - (item.desconto || 0);

        await connection.execute(
          `INSERT INTO venda_itens (venda_id, produto_id, quantidade, preco_unitario, desconto, subtotal) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [vendaId, item.produto_id, item.quantidade, item.preco_unitario, item.desconto || 0, subtotal]
        );

        // Atualizar estoque do produto
        await connection.execute(
          'UPDATE produtos SET estoque = estoque - ? WHERE id = ?',
          [item.quantidade, item.produto_id]
        );

        totalBruto += item.preco_unitario * item.quantidade;
        totalDesconto += item.desconto || 0;
      }

      const totalLiquido = totalBruto - totalDesconto;

      // 4. Atualizar totais da venda
      await connection.execute(
        `UPDATE ${this.tableName} SET 
         total_bruto = ?, total_desconto = ?, total_liquido = ? 
         WHERE id = ?`,
        [totalBruto, totalDesconto, totalLiquido, vendaId]
      );

      await connection.commit();

      return {
        id: vendaId,
        codigo: vendaCode,
        cliente_id: vendaData.cliente_id,
        status: 'aberta',
        total_bruto: totalBruto,
        total_desconto: totalDesconto,
        total_liquido: totalLiquido,
        items: items
      };

    } catch (error) {
      if (connection) await connection.rollback();
      console.error('Erro ao criar venda:', error);
      throw error;
    } finally {
      if (connection) connection.release();
    }
  }

  // -----------------------------------------------------------------

  static async updateWithItems(vendaId, vendaData, newItems) {
    let connection;
    try {
      connection = await pool.getConnection();
      await connection.beginTransaction();

      // --- ETAPA 1: REVERTER ESTOQUE ANTIGO ---

      // 1a. Buscar itens antigos (usando 'venda_itens')
      const [oldItems] = await connection.execute(
        'SELECT produto_id, quantidade FROM venda_itens WHERE venda_id = ?',
        [vendaId]
      );

      // 1b. Devolver estoque dos itens antigos (usando 'produtos')
      for (const item of oldItems) {
        await connection.execute(
          'UPDATE produtos SET estoque = estoque + ? WHERE id = ?',
          [item.quantidade, item.produto_id]
        );
      }

      // 1c. Deletar os itens antigos da venda (usando 'venda_itens')
      await connection.execute('DELETE FROM venda_itens WHERE venda_id = ?', [vendaId]);

      // --- ETAPA 2: INSERIR NOVOS ITENS E CALCULAR TOTAIS ---

      let totalBruto = 0;
      let totalDesconto = 0;

      for (const item of newItems) {
        // 2a. Buscar dados seguros do produto (preço e estoque) (usando 'produtos')
        const [produtoRows] = await connection.execute(
          'SELECT preco, estoque FROM produtos WHERE id = ?',
          [item.produto_id]
        );

        if (produtoRows.length === 0) {
          throw new Error(`Produto ID ${item.produto_id} não encontrado.`);
        }
        const produto = produtoRows[0];

        // 2b. Validar estoque novo
        const quantidade = Number(item.quantidade);
        if (produto.estoque < quantidade) {
          throw new Error(`Estoque insuficiente para o produto ID ${item.produto_id}.`);
        }

        const preco_unitario = Number(produto.preco);
        const desconto = Number(item.desconto) || 0;
        const subtotal = (preco_unitario * quantidade) - desconto;

        // 2c. Inserir o novo item (usando 'venda_itens')
        await connection.execute(
          `INSERT INTO venda_itens (venda_id, produto_id, quantidade, preco_unitario, desconto, subtotal) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [vendaId, item.produto_id, quantidade, preco_unitario, desconto, subtotal]
        );

        // 2d. Dar baixa no estoque do novo item (usando 'produtos')
        await connection.execute(
          'UPDATE produtos SET estoque = estoque - ? WHERE id = ?',
          [quantidade, item.produto_id]
        );

        // 2e. Calcular totais
        totalBruto += preco_unitario * quantidade;
        totalDesconto += desconto;
      }

      const totalLiquido = totalBruto - totalDesconto;

      // --- ETAPA 3: ATUALIZAR O CABEÇALHO DA VENDA (usando this.tableName) ---
      await connection.execute(
        `UPDATE ${this.tableName} SET 
           cliente_id = ?, 
           status = ?, 
           total_bruto = ?, 
           total_desconto = ?, 
           total_liquido = ? 
         WHERE id = ?`,
        [vendaData.cliente_id, vendaData.status, totalBruto, totalDesconto, totalLiquido, vendaId]
      );

      // --- ETAPA 4: SUCESSO! ---
      await connection.commit();

      // Retornar os dados atualizados
      return await this.findWithDetails(vendaId);

    } catch (error) {
      if (connection) await connection.rollback();
      console.error('Erro na transação de atualização de venda:', error);
      // Lança o erro para o controller capturar e enviar o { success: false }
      throw error;
    } finally {
      if (connection) connection.release();
    }
  }

  // Buscar venda com detalhes completos
  static async findWithDetails(id) {
    const [venda] = await this.query(
      `SELECT v.*, c.nome as cliente_nome, c.documento as cliente_documento 
       FROM ${this.tableName} v 
       LEFT JOIN clientes c ON v.cliente_id = c.id 
       WHERE v.id = ?`,
      [id]
    );

    if (!venda) return null;

    const items = await this.query(
      `SELECT 
         vi.*, 
         p.nome as produto_nome, 
         p.sku as produto_sku,
         (vi.preco_unitario * vi.quantidade) as total_bruto_item
       FROM venda_itens vi 
       LEFT JOIN produtos p ON vi.produto_id = p.id 
       WHERE vi.venda_id = ?`,
      [id]
    );

    return {
      ...venda,
      items: items
    };
  }

  // Listar vendas com filtros
static async search(filters = {}) {
  const { search, cliente, startDate, endDate, status, page = 1, limit = 10 } = filters;
  const offset = (page - 1) * limit;
  
  let whereConditions = [];
  let params = [];

  // CORREÇÃO: Aceitar tanto 'search' quanto 'cliente' para compatibilidade
  const searchTerm = search || cliente;
  
  if (searchTerm && searchTerm.trim()) {
    // CORREÇÃO: Buscar em código da venda, nome do cliente E documento
    whereConditions.push('(v.codigo = ? OR c.nome LIKE ? OR c.documento LIKE ?)');
    params.push(searchTerm.trim(), `%${searchTerm.trim()}%`, `%${searchTerm.trim()}%`);
    
    console.log('🔍 Buscando por:', searchTerm);
    console.log('📋 Campos: código da venda (EXATO), nome do cliente, documento');
  }

  if (status && status.trim()) {
    whereConditions.push('v.status = ?');
    params.push(status.trim());
  }

  if (startDate && endDate) {
    whereConditions.push('v.data_hora BETWEEN ? AND ?');
    params.push(startDate, endDate);
  }

  const whereClause = whereConditions.length > 0 
    ? `WHERE ${whereConditions.join(' AND ')}` 
    : '';

  const sql = `
    SELECT
      v.*,
      c.nome as cliente_nome,
      c.documento as cliente_documento
    FROM vendas v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ${whereClause}
    ORDER BY v.data_hora DESC
    LIMIT ? OFFSET ?
  `;

  const countSql = `
    SELECT COUNT(*) as total
    FROM vendas v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ${whereClause}
  `;

  console.log('🔍 SQL Executado:', sql);
  console.log('📋 Parâmetros:', [...params, limit, offset]);

  try {
    const [vendas, countResult] = await Promise.all([
      this.query(sql, [...params, limit, offset]),
      this.query(countSql, params)
    ]);

    console.log('✅ Busca concluída:');
    console.log(`- Termo buscado: "${searchTerm}"`);
    console.log(`- Vendas encontradas: ${vendas.length}`);
    console.log(`- Total no banco: ${countResult[0].total}`);
    
    // Log detalhado dos resultados
    if (vendas.length > 0) {
      console.log('📋 Vendas encontradas:');
      vendas.forEach((venda, idx) => {
        console.log(`  ${idx + 1}. Código: ${venda.codigo}, Cliente: ${venda.cliente_nome}, Documento: ${venda.cliente_documento}`);
      });
    } else {
      console.log('❌ Nenhuma venda encontrada com o termo:', searchTerm);
    }

    return {
      data: vendas,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total,
        totalPages: Math.ceil(countResult[0].total / limit)
      }
    };
  } catch (error) {
    console.error('❌ Erro na busca:', error);
    throw error;
  }
}

  // Atualizar status da venda
  static async updateStatus(id, status) {
    await this.query(
      `UPDATE ${this.tableName} SET status = ? WHERE id = ?`,
      [status, id]
    );
  }
}