import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { testPoolConnection } from './database/connection.js';

// Importar rotas
import produtosRoutes from './routes/produtosRoutes.js';
import clienteRoutes from './routes/clienteRoutes.js';
import vendaRoutes from './routes/vendaRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';

// Carregar variáveis de ambiente
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Rotas da API
app.use('/api/produtos', produtosRoutes);
app.use('/api/clientes', clienteRoutes);
app.use('/api/vendas', vendaRoutes);
app.use('/api/dashboard', dashboardRoutes);


// Rota padrão
app.get('/', (req, res) => {
  res.json({
    message: 'API de Gerenciamento de Vendas',
    version: '1.0.0',
    endpoints: {
      produtos: '/api/produtos',
      clientes: '/api/clientes',
      vendas: '/api/vendas',
      dashboard: '/api/dashboard'
    }
  });
});

// Rota não encontrada
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Rota não encontrada',
    path: req.originalUrl
  });
});

// Error handler
app.use((error, req, res, next) => {
  console.error('Erro não tratado:', error);
  res.status(500).json({
    error: 'Erro interno do servidor',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
  });
});

// Iniciar servidor
async function startServer() {
  try {
    const dbConnected = await testPoolConnection();
    
    if (!dbConnected) {
      console.error('❌ Não foi possível conectar ao banco de dados. Encerrando...');
      process.exit(1);
    }

    app.listen(PORT, () => {
      console.log('Servidor iniciado com sucesso!');
      console.log(`URL: http://localhost:${PORT}`);
      console.log(`Produtos: http://localhost:${PORT}/api/produtos`);
      console.log(`Clientes: http://localhost:${PORT}/api/clientes`);
      console.log(`Vendas: http://localhost:${PORT}/api/vendas`);
      console.log(`Dashboard: http://localhost:${PORT}/api/dashboard`);
    });
  } catch (error) {
    console.error('Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

startServer();