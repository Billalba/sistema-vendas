import { Dashboard } from '../models/Dashboard.js';

export class DashboardController {
  // Obter dados completos do dashboard
  static async getDashboardData(req, res) {
    try {
      const { period = 7 } = req.query;

      const [
        generalStats,
        vendasByPeriod,
        topProdutos,
        vendasByStatus,
        topClientes
      ] = await Promise.all([
        Dashboard.getGeneralStats(),
        Dashboard.getVendasByPeriod(parseInt(period)),
        Dashboard.getTopProdutos(),
        Dashboard.getVendasByStatus(),
        Dashboard.getTopClientes()
      ]);

      res.json({
        success: true,
        data: {
          generalStats,
          vendasByPeriod,
          topProdutos,
          vendasByStatus,
          topClientes
        }
      });

    } catch (error) {
      console.error('Erro ao buscar dados do dashboard:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar dados do dashboard',
        message: error.message
      });
    }
  }

  // Apenas estatísticas gerais
  static async getGeneralStats(req, res) {
    try {
      const stats = await Dashboard.getGeneralStats();

      res.json({
        success: true,
        data: stats
      });

    } catch (error) {
      console.error('Erro ao buscar estatísticas:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar estatísticas',
        message: error.message
      });
    }
  }

  // Vendas por período
  static async getVendasByPeriod(req, res) {
    try {
      const { days = 7 } = req.query;
      const vendas = await Dashboard.getVendasByPeriod(parseInt(days));

      res.json({
        success: true,
        data: vendas
      });

    } catch (error) {
      console.error('Erro ao buscar vendas por período:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar vendas por período',
        message: error.message
      });
    }
  }
}