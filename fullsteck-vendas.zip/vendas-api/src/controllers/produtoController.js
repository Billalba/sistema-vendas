import { Produto } from '../models/Produto.js';

export class ProdutoController {
  // Listar produtos com busca e paginação
  static async getProdutos(req, res) {
    try {
      const { search, page = 1, limit = 10 } = req.query;
      
      const result = await Produto.search(search, parseInt(page), parseInt(limit));
      
      res.json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
      
    } catch (error) {
      console.error('Erro ao buscar produtos:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar produtos',
        message: error.message
      });
    }
  }

  // Obter detalhes de um produto
  static async getProdutoById(req, res) {
    try {
      const { id } = req.params;
      
      const produto = await Produto.findById(parseInt(id));
      
      if (!produto) {
        return res.status(404).json({
          success: false,
          error: 'Produto não encontrado'
        });
      }
      
      res.json({
        success: true,
        data: produto
      });
      
    } catch (error) {
      console.error('Erro ao buscar produto:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar produto',
        message: error.message
      });
    }
  }

  // Buscar produto por SKU
  static async getProdutoBySku(req, res) {
    try {
      const { sku } = req.params;
      
      const produto = await Produto.findBySku(sku);
      
      if (!produto) {
        return res.status(404).json({
          success: false,
          error: 'Produto não encontrado'
        });
      }
      
      res.json({
        success: true,
        data: produto
      });
      
    } catch (error) {
      console.error('Erro ao buscar produto por SKU:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar produto',
        message: error.message
      });
    }
  }
}