import { Venda } from '../models/Venda.js';
import { Cliente } from '../models/Cliente.js';
import { Produto } from '../models/Produto.js';

export class VendaController {

  // Criar nova venda (POST /api/vendas)
  static async createVenda(req, res) {
    try {
      const { cliente_id, items } = req.body;

      // Validar se cliente existe
      const cliente = await Cliente.findById(cliente_id);
      if (!cliente) {
        return res.status(404).json({
          success: false,
          error: 'Cliente não encontrado'
        });
      }

      // Validar itens
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'A venda deve conter pelo menos um item'
        });
      }

      // Validar produtos e estoque
      for (const item of items) {
        const produto = await Produto.findById(item.produto_id);
        if (!produto) {
          return res.status(404).json({
            success: false,
            error: `Produto com ID ${item.produto_id} não encontrado`
          });
        }

        // Esta validação de estoque deve ser tratada pelo seu Model
        // (ex: dentro de uma transação ao criar os itens)
        if (produto.estoque < item.quantidade) {
          return res.status(400).json({
            success: false,
            error: `Estoque insuficiente para o produto: ${produto.nome}`
          });
        }
      }

      // Criar venda
      // Assumindo que o Model 'Venda.createWithItems' lida com a transação
      // e a atualização de estoque.
      const venda = await Venda.createWithItems({ cliente_id, status: 'aberta' }, items);

      res.status(201).json({
        success: true,
        data: venda,
        message: 'Venda criada com sucesso'
      });

    } catch (error) {
      console.error('Erro ao criar venda:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao criar venda',
        message: error.message
      });
    }
  }

  // Listar vendas com filtros (GET /api/vendas)
  static async getVendas(req, res) {
    try {
      const { search, cliente, startDate, endDate, status, page = 1, limit = 10 } = req.query;

      // CORREÇÃO: Usar 'search' se existir, senão usar 'cliente' (backward compatibility)
      const searchTerm = search || cliente;

      const result = await Venda.search({
        search: searchTerm, // Envia como 'search' para o modelo
        startDate,
        endDate,
        status,
        page: parseInt(page),
        limit: parseInt(limit)
      });

      res.json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
    } catch (error) {
      console.error('Erro ao buscar vendas:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar vendas',
        message: error.message
      });
    }
  }

  // Obter detalhes de uma venda (GET /api/vendas/:id)
  static async getVendaById(req, res) {
    try {
      const { id } = req.params;

      const venda = await Venda.findWithDetails(parseInt(id));

      if (!venda) {
        return res.status(404).json({
          success: false,
          error: 'Venda não encontrada'
        });
      }

      res.json({
        success: true,
        data: venda
      });

    } catch (error) {
      console.error('Erro ao buscar venda:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar venda',
        message: error.message
      });
    }
  }

  // -----------------------------------------------------------------
  
  static async updateVenda(req, res) {
    try {
      const { id } = req.params;
      const vendaId = parseInt(id);

      // O frontend envia 'cliente_id', 'status' e 'items'
      const { cliente_id, status, items } = req.body;

      // 1. Validar se cliente existe
      const cliente = await Cliente.findById(cliente_id);
      if (!cliente) {
        return res.status(404).json({
          success: false,
          error: 'Cliente não encontrado'
        });
      }

      // 2. Validar itens
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'A venda deve conter pelo menos um item'
        });
      }

      // 3. Validar produtos e estoque
      // (Esta lógica é complexa e idealmente tratada pelo Model dentro de uma transação)
      for (const item of items) {
        const produto = await Produto.findById(item.produto_id);
        if (!produto) {
          return res.status(404).json({
            success: false,
            error: `Produto com ID ${item.produto_id} não encontrado`
          });
        }
        // Aqui seria necessário um cálculo de *diferença* de estoque
        // Mas por simplicidade, apenas validamos se o produto existe.
        // A lógica de estoque deve ficar no Model.
      }

      // 4. Montar dados do cabeçalho da venda
      const vendaData = {
        cliente_id,
        status
      };

      // 5. Chamar o Model para atualizar
      // Assumindo que você tenha um método no Model 'Venda' para 
      // atualizar a venda e seus itens (ex: deletando os antigos e inserindo os novos)
      // dentro de uma transação.
      const updatedVenda = await Venda.updateWithItems(vendaId, vendaData, items);

      if (!updatedVenda) {
        return res.status(404).json({
          success: false,
          error: 'Venda não encontrada para atualização'
        });
      }

      res.status(200).json({ // 200 OK para atualização
        success: true,
        data: updatedVenda,
        message: 'Venda atualizada com sucesso'
      });

    } catch (error) {
      console.error('Erro ao ATUALIZAR venda:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao atualizar venda',
        message: error.message
      });
    }
  }

  // Atualizar status da venda (PATCH /api/vendas/:id/status)
  static async updateVendaStatus(req, res) {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const validStatus = ['aberta', 'concluida', 'cancelada'];
      if (!validStatus.includes(status)) {
        return res.status(400).json({
          success: false,
          error: 'Status inválido. Use: aberta, concluida ou cancelada'
        });
      }

      await Venda.updateStatus(parseInt(id), status);

      res.json({
        success: true,
        message: `Status da venda atualizado para: ${status}`
      });

    } catch (error) {
      console.error('Erro ao atualizar status da venda:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao atualizar status',
        message: error.message
      });
    }
  }

}