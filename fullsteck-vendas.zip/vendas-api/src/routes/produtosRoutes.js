import express from 'express';
import { ProdutoController } from '../controllers/produtoController.js';

const router = express.Router();

// GET /api/produtos - Listar produtos com busca e paginação
router.get('/', ProdutoController.getProdutos);

// GET /api/produtos/:id - Obter produto por ID
router.get('/:id', ProdutoController.getProdutoById);

// GET /api/produtos/sku/:sku - Obter produto por SKU
router.get('/sku/:sku', ProdutoController.getProdutoBySku);

export default router;