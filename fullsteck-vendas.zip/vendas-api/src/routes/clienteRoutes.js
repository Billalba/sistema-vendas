import express from 'express';
import { ClienteController } from '../controllers/clienteController.js';

const router = express.Router();

// GET /api/clientes - Listar clientes com busca e paginação
router.get('/', ClienteController.getClientes);

// GET /api/clientes/:id - Obter cliente por ID
router.get('/:id', ClienteController.getClienteById);

export default router;