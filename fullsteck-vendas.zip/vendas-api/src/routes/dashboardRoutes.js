import express from 'express';
import { DashboardController } from '../controllers/dashboardController.js';

const router = express.Router();

// GET /api/dashboard - Dados completos do dashboard
router.get('/', DashboardController.getDashboardData);

// GET /api/dashboard/stats - Apenas estatísticas gerais
router.get('/stats', DashboardController.getGeneralStats);

// GET /api/dashboard/vendas-period - Vendas por período
router.get('/vendas-period', DashboardController.getVendasByPeriod);

export default router;