# Instalação Frontend
npm install

# Rodar
npm run dev

# Acesso
http://localhost:5173/

# Considerações
# Bibliotecas principais usadas
 - axios para fazer as requisições
 - vite para vsialização mais rápida do front
 - bootstrap para layout do front
 - react-icons para os icons do Navigation.tsx