import React from "react";
import { FaCartPlus, FaPlus, FaHome, FaTachometerAlt  } from 'react-icons/fa';

const Navigation: React.FC = () => {
  return (
    <nav className="navbar navbar-dark bg-primary mb-4">
    <div className="container">
      <span className="navbar-brand mb-0 h1"><a className="nav-link mx-2 text-light" href="/vendas"> <FaHome /> Sistema de Vendas</a></span>
      <div className="navbar-nav flex-row">
        <a className="nav-link mx-2 text-light" text-light href="/vendas">
        <FaCartPlus /> Vendas
        </a>
        <a className="nav-link mx-2 text-light" href="/vendas/nova">
          <FaPlus /> Nova Venda
        </a>
        <a className="nav-link mx-2 text-light" href="/dashboard">
        <FaTachometerAlt  /> Dashboard
        </a>
      </div>
    </div>
  </nav>
  );
};

export default Navigation;