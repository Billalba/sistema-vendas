import axios, { isAxiosError } from "axios";

const API_BASE = 'http://localhost:3001/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

export default api;

export { isAxiosError };