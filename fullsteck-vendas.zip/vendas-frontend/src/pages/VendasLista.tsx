import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api, { isAxiosError } from "../services/api";

interface Venda {
  id: number;
  codigo: string;
  data_hora: string;
  cliente_id: number;
  cliente_nome?: string;
  cliente_documento?: string;
  status: "aberta" | "concluida" | "cancelada";
  total_bruto: number;
  total_desconto: number;
  total_liquido: number;
  items: any[];
}

interface PaginationInfo {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

const VendasList: React.FC = () => {
  const navigate = useNavigate();
  const [vendas, setVendas] = useState<Venda[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [activeFilters, setActiveFilters] = useState({
    cliente: "", // VOLTE para 'cliente'
    status: ""
  });
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0
  });

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Função para atualizar o status da venda
  const updateVendaStatus = async (vendaId: number, newStatus: string) => {
    try {
      // 1. Usa api.patch() e passa apenas o final da URL.
      // 2. O 'body' é passado como segundo argumento (axios cuida do JSON).
      const response = await api.patch(`/vendas/${vendaId}/status`, { status: newStatus });

      // 3. Os dados já vêm em 'response.data'.
      const result = response.data;

      // 4. A lógica de sucesso permanece a mesma.
      if (result.success) {
        await loadVendas(); // (Assumindo que loadVendas existe neste componente)
      } else {
        alert("Erro ao atualizar status: " + result.error);
      }
    } catch (error: any) {
      // 5. Tratamento de erro aprimorado do axios.
      if (isAxiosError(error)) {
        // Pega o erro específico do backend, se houver.
        const apiError = error.response?.data?.error;
        alert("Erro de API: " + (apiError || error.message));
      } else {
        alert("Erro de conexão ao atualizar status");
      }
    }
  };

  // Função de pesquisa
  const handleSearch = () => {
    if (searchInput.trim()) {
      setActiveFilters({
        ...activeFilters,
        cliente: searchInput.trim() // VOLTE para 'cliente'
      });
      setPagination((prev) => ({ ...prev, page: 1 }));
    }
  };

  // Função para limpar apenas a pesquisa de cliente
  const handleClearSearch = () => {
    setSearchInput("");
    setActiveFilters({
      ...activeFilters,
      cliente: "" // VOLTE para 'cliente'
    });
  };

  // Função para limpar TODOS os filtros
  const handleClearAllFilters = () => {
    setSearchInput("");
    setActiveFilters({
      cliente: "", // VOLTE para 'cliente'
      status: ""
    });
    setPagination((prev) => ({ ...prev, page: 1 }));
  };

  // CARREGAR VENDAS - função principal
  const loadVendas = async (page = pagination.page, limit = pagination.limit) => {
    try {
      setLoading(true);
      setError("");

      console.log("🔍 Carregando vendas:", { page, limit, filters: activeFilters });

      const options = {
        params: {
          page: page.toString(),
          limit: limit.toString(),
          cliente: activeFilters.cliente || undefined, // VOLTE para 'cliente'
          status: activeFilters.status || undefined
        }
      };

      // 2. Chamada principal com 'api.get'
      const response = await api.get("/vendas", options);
      const data = response.data; // axios já faz o .json()

      if (data.success) {
        // 3. Chamadas de detalhe (N+1) agora com 'api.get'
        const vendasWithDetails = await Promise.all(
          data.data.map(async (venda: any) => {
            try {
              // 4. Chamada de detalhe com 'api.get'
              const detailResponse = await api.get(`/vendas/${venda.id}`);
              const detailData = detailResponse.data; // axios já faz o .json()

              if (detailData.success) {
                return {
                  ...venda,
                  total_bruto: Number(venda.total_bruto) || 0,
                  total_desconto: Number(venda.total_desconto) || 0,
                  total_liquido: Number(venda.total_liquido) || 0,
                  items: detailData.data.items || [],
                  cliente_nome: detailData.data.cliente_nome || venda.cliente_nome,
                  cliente_documento: detailData.data.cliente_documento
                };
              }
            } catch (error) {
              console.error(`Erro ao buscar detalhes da venda ${venda.id}:`, error);
            }

            return {
              ...venda,
              total_bruto: Number(venda.total_bruto) || 0,
              total_desconto: Number(venda.total_desconto) || 0,
              total_liquido: Number(venda.total_liquido) || 0,
              items: [],
              cliente_nome: venda.cliente_nome,
              cliente_documento: venda.cliente_documento
            };
          })
        );

        setVendas(vendasWithDetails);
        setPagination((prev) => ({
          ...prev,
          ...data.pagination,
          page: data.pagination?.page || page,
          limit: data.pagination?.limit || limit
        }));

        console.log("✅ Vendas carregadas:", vendasWithDetails.length);
      } else {
        setError("Erro ao carregar vendas: " + (data.error || "Erro desconhecido"));
      }
    } catch (err: any) {
      // 5. Tratamento de erro principal (do axios)
      console.error("❌ Erro na requisição:", err);
      if (isAxiosError(err)) {
        setError(err.response?.data?.error || `Erro de API: ${err.message}`);
      } else {
        setError("Erro de conexão. Verifique se o backend está rodando.");
      }
    } finally {
      setLoading(false);
    }
  };

  // EFFECT para carregar vendas quando filters ou pagination.limit mudarem
  useEffect(() => {
    console.log("🔄 Recarregando vendas devido a mudanças:", {
      filters: activeFilters,
      limit: pagination.limit
    });
    loadVendas(1, pagination.limit);
  }, [activeFilters, pagination.limit]);

  // Função para lidar com a tecla Enter
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // Funções para navegar entre páginas
  const goToPage = (page: number) => {
    if (page >= 1 && page <= pagination.totalPages) {
      loadVendas(page, pagination.limit);
    }
  };

  // Mudança no limite de itens por página
  const changeLimit = (newLimit: number) => {
    console.log("📄 Alterando limite para:", newLimit);
    setPagination((prev) => ({
      ...prev,
      limit: newLimit,
      page: 1
    }));
  };

  // Atualizar filtro de status
  const handleStatusChange = (status: string) => {
    setActiveFilters({
      ...activeFilters,
      status: status
    });
    setPagination((prev) => ({ ...prev, page: 1 }));
  };

  const formatCurrency = (value: number) => {
    if (isNaN(value) || value === null || value === undefined) {
      return "R$ 0,00";
    }
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString("pt-BR");
    } catch {
      return "Data inválida";
    }
  };

  const formatDocument = (document: string) => {
    if (!document) return "";
    if (document.length === 11) {
      return document.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    }
    if (document.length === 14) {
      return document.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
    }
    return document;
  };

  const getStatusBadge = (status: string) => {
    const variants: any = {
      aberta: "warning",
      concluida: "success",
      cancelada: "danger"
    };
    return <span className={`badge bg-${variants[status]}`}>{status}</span>;
  };

  if (loading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Carregando...</span>
        </div>
        <p className="mt-2">Carregando vendas...</p>
      </div>
    );
  }

  // Cálculos
  const completedVendas = vendas.filter((s) => s.status === "concluida");
  const totalRevenue = completedVendas.reduce((sum, venda) => sum + (venda.total_liquido || 0), 0);
  const averageTicket = completedVendas.length > 0 ? totalRevenue / completedVendas.length : 0;

  // Verificar se há filtros ativos
  const hasActiveFilters = activeFilters.cliente || activeFilters.status;

  return (
    <div>
      {/* Cabeçalho */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Listagem de Vendas</h1>
        <div>
          <button className="btn btn-outline-secondary me-2" onClick={() => loadVendas(1, pagination.limit)}>
            Atualizar
          </button>
          <button className="btn btn-primary" onClick={() => navigate("/vendas/nova")}>
            Nova Venda
          </button>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {/* Filtros */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row">
            {/* Busca por Cliente com Botão */}
            <div className="col-md-4">
              <label htmlFor="clienteFilter" className="form-label">
                Buscar por Cliente:
              </label>
              <div className="input-group">
                <input
                  ref={searchInputRef}
                  type="text"
                  className="form-control"
                  id="clienteFilter"
                  placeholder="Nome, CPF ou CNPJ do cliente..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                />
                {searchInput && (
                  <button className="btn btn-outline-secondary" type="button" onClick={handleClearSearch} title="Limpar pesquisa">
                    X
                  </button>
                )}
                <button className="btn btn-primary" type="button" onClick={handleSearch} disabled={!searchInput.trim()}>
                  Pesquisar
                </button>
              </div>
              <div className="form-text">Digite e pressione Enter ou clique em Pesquisar</div>
            </div>

            {/* Filtro de Status */}
            <div className="col-md-4">
              <label htmlFor="statusFilter" className="form-label">
                Status da Venda:
              </label>
              <select className="form-select" id="statusFilter" value={activeFilters.status} onChange={(e) => handleStatusChange(e.target.value)}>
                <option value="">Todos os status</option>
                <option value="aberta">🟡 Aberta</option>
                <option value="concluida">🟢 Concluída</option>
                <option value="cancelada">🔴 Cancelada</option>
              </select>
            </div>

            {/* Itens por página */}
            <div className="col-md-4">
              <label htmlFor="limitFilter" className="form-label">
                Itens por página:
              </label>
              <select className="form-select" id="limitFilter" value={pagination.limit} onChange={(e) => changeLimit(Number(e.target.value))}>
                <option value="5">5 itens</option>
                <option value="10">10 itens</option>
                <option value="20">20 itens</option>
                <option value="50">50 itens</option>
              </select>
            </div>
          </div>

          {/* Botão Limpar Todos os Filtros */}
          {hasActiveFilters && (
            <div className="row mt-3">
              <div className="col-12">
                <button className="btn btn-outline-danger btn-sm" onClick={handleClearAllFilters}>
                  Limpar Todos os Filtros
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Contador de resultados */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <small className="text-muted">
          Mostrando {vendas.length} de {pagination.total} vendas
          {pagination.totalPages > 1 && ` (Página ${pagination.page} de ${pagination.totalPages})`}
          {pagination.limit !== 10 && ` | ${pagination.limit} por página`}
        </small>

        {/* Indicadores de Filtros Ativos */}
        <div className="d-flex align-items-center gap-2">
          {activeFilters.cliente && <span className="badge bg-info"> Busca: "{activeFilters.cliente}"</span>}
          {activeFilters.status && <span className="badge bg-warning"> Status: {activeFilters.status}</span>}
        </div>
      </div>

      {/* Tabela de Vendas */}
      <div className="card">
        <div className="card-body">
          {vendas.length === 0 ? (
            <div className="text-center text-muted py-5">
              <h4>📭 Nenhuma venda encontrada</h4>
              <p>{pagination.total === 0 ? 'Crie sua primeira venda clicando no botão "Nova Venda"' : "Nenhuma venda corresponde aos filtros aplicados"}</p>
              {pagination.total === 0 ? (
                <button className="btn btn-primary mt-2" onClick={() => navigate("/vendas/nova")}>
                  + Criar Primeira Venda
                </button>
              ) : (
                <button className="btn btn-outline-primary mt-2" onClick={handleClearAllFilters}>
                  X Limpar Filtros
                </button>
              )}
            </div>
          ) : (
            <>
              <div className="table-responsive">
                <table className="table table-striped table-hover">
                  <thead className="table-dark">
                    <tr>
                      <th>Código</th>
                      <th>Data/Hora</th>
                      <th>Cliente</th>
                      <th>Documento</th>
                      <th>Status</th>
                      <th>Itens</th>
                      <th>Total</th>
                      <th>Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendas.map((venda) => (
                      <tr key={venda.id}>
                        <td>
                          <strong>{venda.codigo}</strong>
                        </td>
                        <td>{formatDate(venda.data_hora)}</td>
                        <td>
                          <div>
                            <strong>{venda.cliente_nome || `Cliente #${venda.cliente_id}`}</strong>
                          </div>
                        </td>
                        <td>
                          <small className="text-muted">{venda.cliente_documento ? formatDocument(venda.cliente_documento) : "N/A"}</small>
                        </td>
                        <td>{getStatusBadge(venda.status)}</td>
                        <td>
                          <span className="badge bg-info">{venda.items ? venda.items.length : 0} itens</span>
                        </td>
                        <td>
                          <strong>{formatCurrency(venda.total_liquido)}</strong>
                        </td>
                        <td>
                          <div className="btn-group-vertical btn-group-sm" role="group">
                            <button className="btn btn-outline-primary mb-1" onClick={() => navigate(`/vendas/editar/${venda.id}`)} title="Ver Detalhes">
                              Ver
                            </button>

                            {venda.status === "concluida" && (
                              <button className="btn btn-outline-danger" onClick={() => updateVendaStatus(venda.id, "cancelada")} title="Cancelar Venda">
                                Cancelar
                              </button>
                            )}

                            {venda.status === "cancelada" && (
                              <button className="btn btn-outline-warning" onClick={() => updateVendaStatus(venda.id, "concluida")} title="Reativar Venda">
                                Reativar
                              </button>
                            )}

                            {venda.status === "aberta" && (
                              <button className="btn btn-outline-success" onClick={() => updateVendaStatus(venda.id, "concluida")} title="Concluir Venda">
                                Concluir
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Paginação */}
              {pagination.totalPages > 1 && (
                <nav aria-label="Navegação de páginas" className="mt-4">
                  <ul className="pagination justify-content-center">
                    <li className={`page-item ${pagination.page === 1 ? "disabled" : ""}`}>
                      <button className="page-link" onClick={() => goToPage(pagination.page - 1)} disabled={pagination.page === 1}>
                        &laquo; Anterior
                      </button>
                    </li>

                    {[...Array(pagination.totalPages)].map((_, index) => {
                      const pageNumber = index + 1;
                      if (pageNumber === 1 || pageNumber === pagination.totalPages || (pageNumber >= pagination.page - 1 && pageNumber <= pagination.page + 1)) {
                        return (
                          <li key={pageNumber} className={`page-item ${pagination.page === pageNumber ? "active" : ""}`}>
                            <button className="page-link" onClick={() => goToPage(pageNumber)}>
                              {pageNumber}
                            </button>
                          </li>
                        );
                      } else if (pageNumber === pagination.page - 2 || pageNumber === pagination.page + 2) {
                        return (
                          <li key={pageNumber} className="page-item disabled">
                            <span className="page-link">...</span>
                          </li>
                        );
                      }
                      return null;
                    })}

                    <li className={`page-item ${pagination.page === pagination.totalPages ? "disabled" : ""}`}>
                      <button className="page-link" onClick={() => goToPage(pagination.page + 1)} disabled={pagination.page === pagination.totalPages}>
                        Próximo &raquo;
                      </button>
                    </li>
                  </ul>
                </nav>
              )}
            </>
          )}
        </div>
      </div>

      {/* Estatísticas Rápidas */}
      {vendas.length > 0 && (
        <div className="row mt-4">
          <div className="col-md-3 mb-3">
            <div className="card text-center border-primary">
              <div className="card-body">
                <h5 className="card-title text-primary">Vendas na Página</h5>
                <h2 className="text-primary">{vendas.length}</h2>
                <small className="text-muted">{pagination.total} no total</small>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-center border-success">
              <div className="card-body">
                <h5 className="card-title text-success">Vendas Concluídas</h5>
                <h2 className="text-success">{completedVendas.length}</h2>
                <small className="text-muted">{vendas.length > 0 ? `${((completedVendas.length / vendas.length) * 100).toFixed(1)}% da página` : "0% da página"}</small>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-center border-info">
              <div className="card-body">
                <h5 className="card-title text-info">Receita (Página)</h5>
                <h2 className="text-info">{formatCurrency(totalRevenue)}</h2>
                <small className="text-muted">{completedVendas.length} vendas concluídas</small>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-center border-warning">
              <div className="card-body">
                <h5 className="card-title text-warning">Ticket Médio</h5>
                <h2 className="text-warning">{formatCurrency(averageTicket)}</h2>
                <small className="text-muted">{completedVendas.length > 0 ? "por venda concluída" : "sem vendas"}</small>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendasList;
