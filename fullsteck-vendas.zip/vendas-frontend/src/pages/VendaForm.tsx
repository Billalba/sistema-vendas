import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { isAxiosError } from "../services/api";

// Interfaces
interface Cliente {
  id: number;
  nome: string;
  documento: string;
  email: string;
  telefone: string;
}

interface Produto {
  id: number;
  sku: string;
  nome: string;
  descricao: string;
  preco: number;
  estoque: number;
  ativo: boolean;
}

interface VendaItem {
  produto_id: number;
  quantidade: number;
  preco_unitario: number;
  desconto: number;
  produto_nome?: string;
  produto_sku?: string;
  subtotal?: number;
  id?: number;
  venda_id?: number;
}

interface VendaData {
  id: number;
  codigo?: string;
  cliente_id: number;
  status: "aberta" | "concluida" | "cancelada";
  items: VendaItem[];
  data_hora?: string;
  cliente_nome?: string;
  cliente_documento?: string;
}

const VendaForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id?: string }>();

  // Detecta o modo baseado na presença do ID
  const isEditMode = !!id;
  const vendaId = id ? parseInt(id) : 0;

  // Estados
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [loading, setLoading] = useState({
    initial: false,
    venda: false,
    submit: false
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [formData, setFormData] = useState({
    cliente_id: 0,
    status: "aberta" as "aberta" | "concluida" | "cancelada",
    items: [] as VendaItem[]
  });

  const [selectedProduto, setSelectedProduto] = useState<Produto | null>(null);
  const [quantidade, setQuantidade] = useState(1);
  const [desconto, setDesconto] = useState(0);
  const [showProdutoModal, setShowProdutoModal] = useState(false);

  // Carregar dados iniciais
  useEffect(() => {
    const initializeData = async () => {
      await loadInitialData();

      if (isEditMode && vendaId > 0) {
        await loadVendaForEdit(vendaId);
      } else {
        // Modo criação - garante que o form está limpo
        setFormData({
          cliente_id: 0,
          status: "aberta",
          items: []
        });
      }
    };

    initializeData();
  }, [isEditMode, vendaId]);

  // Funções auxiliares
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  };

  // Converte string digitada para número
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove tudo que não é número
    let numericValue = e.target.value.replace(/\D/g, "");

    // Converte para número real dividindo por 100 (para centavos)
    numericValue = numericValue ? (parseInt(numericValue) / 100).toString() : "0";

    setDesconto(parseFloat(numericValue));
  };

  // Valor exibido formatado
  const displayValue = desconto.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("pt-BR");
  };

  const getStatusBadge = (status: string) => {
    const variants: any = {
      aberta: "warning",
      concluida: "success",
      cancelada: "danger"
    };
    return <span className={`badge bg-${variants[status]}`}>{status.toUpperCase()}</span>;
  };

  const loadInitialData = async () => {
    setLoading((prev) => ({ ...prev, initial: true }));
    setError("");

    try {
      const [clientesResponse, produtosResponse] = await Promise.all([api.get("/clientes", { params: { limit: 100 } }), api.get("/produtos", { params: { limit: 100 } })]);

      const clientesData = clientesResponse.data;
      if (clientesData.success) {
        setClientes(clientesData.data);
      }

      const produtosData = produtosResponse.data;
      if (produtosData.success) {
        const produtosWithNumberPrice = produtosData.data.map((produto: any) => ({
          ...produto,
          preco: Number(produto.preco)
        }));
        setProdutos(produtosWithNumberPrice);
      }
    } catch (err: any) {
      console.error("Erro ao carregar dados iniciais:", err);
      if (isAxiosError(err)) {
        setError(err.response?.data?.error || "Erro de API ao carregar dados.");
      } else {
        setError("Erro ao carregar dados. Verifique se o backend está rodando.");
      }
    } finally {
      setLoading((prev) => ({ ...prev, initial: false }));
    }
  };

  const loadVendaForEdit = async (id: number) => {
    setLoading((prev) => ({ ...prev, venda: true }));
    setError("");
    try {
      const response = await api.get(`/vendas/${id}`);
      const result = response.data;

      if (result.success && result.data) {
        const vendaData: VendaData = result.data;

        const itemsComNumeros = vendaData.items.map((item: any) => ({
          ...item,
          quantidade: Number(item.quantidade),
          preco_unitario: Number(item.preco_unitario),
          desconto: Number(item.desconto),
          subtotal: Number(item.preco_unitario) * Number(item.quantidade) - Number(item.desconto)
        }));

        setFormData({
          cliente_id: vendaData.cliente_id,
          status: vendaData.status,
          items: itemsComNumeros
        });
      } else {
        setError(result.error || "Venda não encontrada.");
        setTimeout(() => navigate("/vendas"), 2000);
      }
    } catch (err: any) {
      console.error("Erro ao buscar dados da venda:", err);
      if (isAxiosError(err)) {
        setError(err.response?.data?.error || `Erro de API: ${err.message}`);
      } else {
        setError("Erro ao buscar dados da venda.");
      }
      setTimeout(() => navigate("/vendas"), 2000);
    } finally {
      setLoading((prev) => ({ ...prev, venda: false }));
    }
  };

  // Funções de manipulação de itens
  const addProdutoToVenda = () => {
    if (!selectedProduto) return;

    // Verifica se o produto já existe na venda
    const existingItemIndex = formData.items.findIndex((item) => item.produto_id === selectedProduto.id);

    let newItems: VendaItem[];

    if (existingItemIndex >= 0) {
      // Atualiza item existente
      newItems = formData.items.map((item, index) =>
        index === existingItemIndex
          ? {
              ...item,
              quantidade: item.quantidade + quantidade,
              desconto: item.desconto + desconto,
              subtotal: item.preco_unitario * (item.quantidade + quantidade) - (item.desconto + desconto)
            }
          : item
      );
    } else {
      // Adiciona novo item
      const newItem: VendaItem = {
        produto_id: selectedProduto.id,
        quantidade: quantidade,
        preco_unitario: selectedProduto.preco,
        desconto: desconto,
        produto_nome: selectedProduto.nome,
        produto_sku: selectedProduto.sku,
        subtotal: selectedProduto.preco * quantidade - desconto
      };
      newItems = [...formData.items, newItem];
    }

    setFormData({
      ...formData,
      items: newItems
    });

    setSelectedProduto(null);
    setQuantidade(1);
    setDesconto(0);
    setShowProdutoModal(false);
  };

  const removeItem = (index: number) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
  };

  const updateItemQuantity = (index: number, newQuantity: number) => {
    if (newQuantity < 1) return;

    const newItems = formData.items.map((item, i) =>
      i === index
        ? {
            ...item,
            quantidade: newQuantity,
            subtotal: item.preco_unitario * newQuantity - item.desconto
          }
        : item
    );

    setFormData({ ...formData, items: newItems });
  };

  const updateItemDiscount = (index: number, newDiscount: number) => {
    if (newDiscount < 0) return;

    const item = formData.items[index];
    const maxDiscount = item.preco_unitario * item.quantidade;

    if (newDiscount > maxDiscount) {
      newDiscount = maxDiscount;
    }

    const newItems = formData.items.map((item, i) =>
      i === index
        ? {
            ...item,
            desconto: newDiscount,
            subtotal: item.preco_unitario * item.quantidade - newDiscount
          }
        : item
    );

    setFormData({ ...formData, items: newItems });
  };

  const calculateTotals = () => {
    const totalBruto = formData.items.reduce((sum, item) => sum + Number(item.preco_unitario) * Number(item.quantidade), 0);
    const totalDesconto = formData.items.reduce((sum, item) => sum + Number(item.desconto), 0);
    const totalLiquido = totalBruto - totalDesconto;

    return { totalBruto, totalDesconto, totalLiquido };
  };

  // Submit unificado
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.cliente_id === 0) {
      setError("Selecione um cliente");
      return;
    }

    if (formData.items.length === 0) {
      setError("Adicione pelo menos um produto à venda");
      return;
    }

    // Valida estoque
    for (const item of formData.items) {
      const produto = produtos.find((p) => p.id === item.produto_id);
      if (produto && item.quantidade > produto.estoque) {
        setError(`Estoque insuficiente para ${produto.nome}. Estoque disponível: ${produto.estoque}`);
        return;
      }
    }

    setLoading((prev) => ({ ...prev, submit: true }));
    setError("");

    const vendaData = {
      cliente_id: formData.cliente_id,
      status: formData.status,
      items: formData.items.map((item) => ({
        produto_id: item.produto_id,
        quantidade: item.quantidade,
        preco_unitario: item.preco_unitario,
        desconto: item.desconto
      }))
    };

    try {
      let response;

      if (isEditMode) {
        response = await api.put(`/vendas/${vendaId}`, vendaData);
      } else {
        response = await api.post("/vendas", vendaData);
      }

      const result = response.data;

      if (result.success) {
        setSuccess(isEditMode ? "Venda atualizada com sucesso!" : "Venda criada com sucesso!");
        setTimeout(() => {
          navigate("/vendas");
        }, 2000);
      } else {
        setError(result.error || (isEditMode ? "Erro ao atualizar venda" : "Erro ao criar venda"));
      }
    } catch (err: any) {
      console.error("Erro ao salvar venda:", err);
      if (isAxiosError(err)) {
        setError(err.response?.data?.error || `Erro de API: ${err.message}`);
      } else {
        setError("Erro de conexão. Verifique se o backend está rodando.");
      }
    } finally {
      setLoading((prev) => ({ ...prev, submit: false }));
    }
  };

  const { totalBruto, totalDesconto, totalLiquido } = calculateTotals();

  if (loading.initial || (isEditMode && loading.venda)) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Carregando...</span>
        </div>
        <p>{loading.venda ? "Carregando dados da venda..." : "Carregando dados iniciais..."}</p>
      </div>
    );
  }

  return (
    <div>
      {/* Cabeçalho */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1>{isEditMode ? ` Editar Venda #${vendaId}` : " Nova Venda"}</h1>
          {isEditMode && <p className="text-muted mb-0">Status: {getStatusBadge(formData.status)}</p>}
        </div>
        <div>
          <button className="btn btn-outline-secondary me-2" onClick={() => navigate("/vendas")}>
             Voltar para Lista
          </button>
          {isEditMode && (
            <button className="btn btn-outline-primary" onClick={() => navigate("/vendas/nova")}>
               Nova Venda
            </button>
          )}
        </div>
      </div>

      {/* Alertas */}
      {error && (
        <div className="alert alert-danger d-flex align-items-center" role="alert">
          <div> {error}</div>
        </div>
      )}

      {success && (
        <div className="alert alert-success d-flex align-items-center" role="alert">
          <div> {success}</div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-8">
            {/* Dados do Cliente */}
            <div className="card mb-4">
              <div className="card-header">
                <h5 className="mb-0"> Dados do Cliente</h5>
              </div>
              <div className="card-body">
                <div className="row">
                  <div className="col-md-8 mb-3">
                    <label className="form-label">Selecione o Cliente *</label>
                    <select
                      className="form-select"
                      value={formData.cliente_id}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          cliente_id: parseInt(e.target.value)
                        })
                      }
                      required
                      disabled={isEditMode} // Normalmente não se muda o cliente na edição
                    >
                      <option value={0} disabled>
                        Selecione um cliente...
                      </option>
                      {clientes.map((cliente) => (
                        <option key={cliente.id} value={cliente.id}>
                          {cliente.nome} - {cliente.documento}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-4 mb-3">
                    <label className="form-label">Status *</label>
                    <select
                      className="form-select"
                      value={formData.status}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          status: e.target.value as "aberta" | "concluida" | "cancelada"
                        })
                      }
                      required
                    >
                      <option value="aberta">Aberta</option>
                      <option value="concluida">Concluída</option>
                      <option value="cancelada">Cancelada</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Produtos da Venda */}
            <div className="card">
              <div className="card-header d-flex justify-content-between align-items-center">
                <h5 className="mb-0"> Produtos da Venda</h5>
                <button type="button" className="btn btn-outline-primary" onClick={() => setShowProdutoModal(true)} disabled={formData.cliente_id === 0}>
                   Adicionar Produto
                </button>
              </div>
              <div className="card-body">
                {formData.items.length === 0 ? (
                  <div className="text-center text-muted py-4">
                    <i className="fas fa-shopping-cart fa-2x mb-3"></i>
                    <p>Nenhum produto adicionado à venda</p>
                    <small>Clique em "Adicionar Produto" para começar</small>
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="table table-striped table-hover">
                      <thead className="table-light">
                        <tr>
                          <th>Produto</th>
                          <th>Quantidade</th>
                          <th>Preço Unit.</th>
                          <th>Desconto</th>
                          <th>Subtotal</th>
                          <th>Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formData.items.map((item, index) => (
                          <tr key={item.id || item.produto_id || index}>
                            <td>
                              <div>
                                <strong>{item.produto_nome}</strong>
                                <br />
                                <small className="text-muted">{item.produto_sku}</small>
                              </div>
                            </td>
                            <td>
                              <div className="input-group input-group-sm" style={{ width: "120px" }}>
                                <button className="btn btn-outline-secondary" type="button" onClick={() => updateItemQuantity(index, item.quantidade - 1)}>
                                  -
                                </button>
                                <input type="number" className="form-control text-center" value={item.quantidade} onChange={(e) => updateItemQuantity(index, parseInt(e.target.value) || 1)} min="1" />
                                <button className="btn btn-outline-secondary" type="button" onClick={() => updateItemQuantity(index, item.quantidade + 1)}>
                                  +
                                </button>
                              </div>
                            </td>
                            <td>{formatCurrency(item.preco_unitario)}</td>
                            <td style={{ width: "100px", textAlign: "right" }}>{item.desconto.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            <td>
                              <strong>{formatCurrency(item.subtotal || 0)}</strong>
                            </td>
                            <td>
                              <button type="button" className="btn btn-outline-danger btn-sm" onClick={() => removeItem(index)} title="Remover item">
                                Excluir
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="col-md-4">
            {/* Resumo da Venda */}
            <div className="card sticky-top" style={{ top: "20px" }}>
              <div className="card-header">
                <h5 className="mb-0"> Resumo da Venda</h5>
              </div>
              <div className="card-body">
                <ul className="list-group list-group-flush mb-3">
                  <li className="list-group-item d-flex justify-content-between align-items-center">
                    <span>Total de Itens:</span>
                    <span className="badge bg-primary rounded-pill">{formData.items.length}</span>
                  </li>
                  <li className="list-group-item d-flex justify-content-between">
                    <span>Total Bruto:</span>
                    <strong>{formatCurrency(totalBruto)}</strong>
                  </li>
                  <li className="list-group-item d-flex justify-content-between">
                    <span>Total Desconto:</span>
                    <strong className="text-danger">-{formatCurrency(totalDesconto)}</strong>
                  </li>
                  <li className="list-group-item d-flex justify-content-between">
                    <span>Total Líquido:</span>
                    <strong className="text-success fs-5">{formatCurrency(totalLiquido)}</strong>
                  </li>
                </ul>

                <div className="d-grid gap-2">
                  <button type="submit" className="btn btn-primary btn-lg" disabled={loading.submit || formData.items.length === 0 || formData.cliente_id === 0}>
                    {loading.submit ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        Processando...
                      </>
                    ) : isEditMode ? (
                      " Salvar Alterações"
                    ) : (
                      " Finalizar Venda"
                    )}
                  </button>

                  {formData.cliente_id === 0 && <small className="text-muted text-center mt-1">Selecione um cliente para habilitar a venda</small>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>

      {/* Modal de Seleção de Produto */}
      {showProdutoModal && (
        <div className="modal show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} tabIndex={-1}>
          <div className="modal-dialog modal-lg modal-dialog-scrollable">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{selectedProduto ? "Configurar Produto" : "Selecionar Produto"}</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => {
                    setShowProdutoModal(false);
                    setSelectedProduto(null);
                  }}
                ></button>
              </div>
              <div className="modal-body">
                {selectedProduto ? (
                  <div>
                    <div className="alert alert-info">
                      <strong>Produto Selecionado:</strong> {selectedProduto.nome}
                      <br />
                      <small>
                        SKU: {selectedProduto.sku} | Preço: {formatCurrency(selectedProduto.preco)}
                      </small>
                    </div>

                    <div className="row mt-3">
                      <div className="col-md-4">
                        <label className="form-label">Quantidade *</label>
                        <input type="number" className="form-control" min="1" max={selectedProduto.estoque} value={quantidade} onChange={(e) => setQuantidade(parseInt(e.target.value) || 1)} />
                        <small className="text-muted">
                          Estoque disponível: <strong>{selectedProduto.estoque}</strong>
                        </small>
                      </div>
                      <div className="col-md-4">
                        <label className="form-label">Desconto (R$)</label>
                        <input type="text" className="form-control" value={displayValue} onChange={handleChange} placeholder="R$ 0,00" />
                        <small>Máximo permitido: {formatCurrency(selectedProduto.preco * quantidade)}</small>
                      </div>
                      <div className="col-md-4">
                        <label className="form-label">Subtotal</label>
                        <input type="text" className="form-control bg-light" value={formatCurrency(selectedProduto.preco * quantidade - desconto)} readOnly />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="mb-3">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Buscar produto por nome ou SKU..."
                        // Você pode implementar a busca aqui
                      />
                    </div>
                    <div className="table-responsive" style={{ maxHeight: "400px" }}>
                      <table className="table table-striped table-hover">
                        <thead className="table-light sticky-top">
                          <tr>
                            <th>Nome</th>
                            <th>SKU</th>
                            <th>Preço</th>
                            <th>Estoque</th>
                            <th>Ação</th>
                          </tr>
                        </thead>
                        <tbody>
                          {produtos
                            .filter((p) => p.ativo)
                            .map((produto) => (
                              <tr key={produto.id} className={produto.estoque === 0 ? "table-danger" : ""}>
                                <td>{produto.nome}</td>
                                <td>
                                  <code>{produto.sku}</code>
                                </td>
                                <td>{formatCurrency(produto.preco)}</td>
                                <td>
                                  <span className={`badge bg-${produto.estoque > 0 ? "success" : "danger"}`}>{produto.estoque}</span>
                                </td>
                                <td>
                                  <button className="btn btn-outline-primary btn-sm" onClick={() => setSelectedProduto(produto)} disabled={produto.estoque === 0}>
                                    {produto.estoque === 0 ? "Sem Estoque" : "Selecionar"}
                                  </button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                {selectedProduto ? (
                  <>
                    <button type="button" className="btn btn-outline-secondary" onClick={() => setSelectedProduto(null)}>
                       Voltar à Lista
                    </button>
                    <button type="button" className="btn btn-primary" onClick={addProdutoToVenda}>
                       Adicionar à Venda
                    </button>
                  </>
                ) : (
                  <button type="button" className="btn btn-secondary" onClick={() => setShowProdutoModal(false)}>
                    Fechar
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendaForm;
