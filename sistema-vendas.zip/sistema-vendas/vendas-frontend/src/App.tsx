import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Header from '../src/components/Navigation'
import { Container } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

// Pages
import VendasLista from "./pages/VendasLista";
import VendaForm from "./pages/VendaForm";
import Dashboard from "./pages/Dashboard";


function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Container fluid className="mt-3">
          <Routes>
            <Route path="/" element={<Navigate to="/vendas" replace />} />
            <Route path="/vendas" element={<VendasLista />} />
            <Route path="/vendas/nova" element={<VendaForm />} />
            <Route path="/vendas/editar/:id" element={<VendaForm />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </Container>
      </div>
    </Router>
  );
}

export default App;
