import React, { useState, useEffect, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { isAxiosError } from "../services/api";

// --- Interfaces ---
interface Cliente {
  id: number;
  nome: string;
  documento: string;
}

interface Produto {
  id: number;
  sku: string;
  nome: string;
  preco: number;
  estoque: number;
  ativo: boolean;
}

interface VendaItem {
  produto_id: number;
  quantidade: number;
  preco_unitario: number;
  desconto: number;
  produto_nome?: string;
  produto_sku?: string;
  subtotal?: number;
}

interface VendaData {
  cliente_id: number;
  status: "aberta" | "concluida" | "cancelada";
  items: VendaItem[];
}

const VendaForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id?: string }>();
  const isEditMode = !!id;
  const vendaId = id ? parseInt(id) : 0;

  // --- Estados ---
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState({ initial: true, submit: false });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [formData, setFormData] = useState<VendaData>({
    cliente_id: 0,
    status: "aberta",
    items: []
  });

  // Estados para o Modal de adição
  const [showProdutoModal, setShowProdutoModal] = useState(false);
  const [selectedProduto, setSelectedProduto] = useState<Produto | null>(null);
  const [inputQuantidade, setInputQuantidade] = useState(1);
  const [inputDesconto, setInputDesconto] = useState(0);

  // --- Inicialização ---
  useEffect(() => {
    const loadData = async () => {
      try {
        const [resCli, resProd] = await Promise.all([
          api.get("/clientes", { params: { limit: 100 } }),
          api.get("/produtos", { params: { limit: 100 } })
        ]);
        
        if (resCli.data.success) setClientes(resCli.data.data);
        if (resProd.data.success) setProdutos(resProd.data.data);

        if (isEditMode) {
          const resVenda = await api.get(`/vendas/${vendaId}`);
          if (resVenda.data.success) {
            const v = resVenda.data.data;
            setFormData({
              cliente_id: v.cliente_id,
              status: v.status,
              items: v.items.map((it: any) => ({
                ...it,
                quantidade: Number(it.quantidade),
                preco_unitario: Number(it.preco_unitario),
                desconto: Number(it.desconto),
                subtotal: Number(it.preco_unitario) * Number(it.quantidade) - Number(it.desconto)
              }))
            });
          }
        }
      } catch (err) {
        setError("Erro ao carregar dados. Verifique a conexão.");
      } finally {
        setLoading(prev => ({ ...prev, initial: false }));
      }
    };
    loadData();
  }, [isEditMode, vendaId]);

  // --- Cálculos e Filtros ---
  const formatCurrency = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  const produtosFiltrados = useMemo(() => {
    return produtos.filter(p => 
      p.ativo && (p.nome.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [produtos, searchTerm]);

  const totals = useMemo(() => {
    const bruto = formData.items.reduce((acc, it) => acc + (it.preco_unitario * it.quantidade), 0);
    const desc = formData.items.reduce((acc, it) => acc + it.desconto, 0);
    return { bruto, desc, liquido: bruto - desc };
  }, [formData.items]);

  // --- Ações de Itens ---
  const addProdutoToVenda = () => {
    if (!selectedProduto) return;

    // Validação de estoque considerando o que já está no carrinho
    const itemExistente = formData.items.find(i => i.produto_id === selectedProduto.id);
    const qtdTotal = (itemExistente?.quantidade || 0) + inputQuantidade;

    if (qtdTotal > selectedProduto.estoque) {
      alert(`Estoque insuficiente! Disponível: ${selectedProduto.estoque}`);
      return;
    }

    setFormData(prev => {
      const index = prev.items.findIndex(i => i.produto_id === selectedProduto.id);
      const newItems = [...prev.items];

      if (index >= 0) {
        const item = newItems[index];
        const novaQtd = item.quantidade + inputQuantidade;
        const novoDesc = item.desconto + inputDesconto;
        newItems[index] = {
          ...item,
          quantidade: novaQtd,
          desconto: novoDesc,
          subtotal: (item.preco_unitario * novaQtd) - novoDesc
        };
      } else {
        newItems.push({
          produto_id: selectedProduto.id,
          produto_nome: selectedProduto.nome,
          produto_sku: selectedProduto.sku,
          quantidade: inputQuantidade,
          preco_unitario: selectedProduto.preco,
          desconto: inputDesconto,
          subtotal: (selectedProduto.preco * inputQuantidade) - inputDesconto
        });
      }
      return { ...prev, items: newItems };
    });

    setShowProdutoModal(false);
    setSelectedProduto(null);
    setInputQuantidade(1);
    setInputDesconto(0);
  };

  const updateItem = (index: number, field: "quantidade" | "desconto", value: number) => {
    setFormData(prev => {
      const newItems = [...prev.items];
      const item = { ...newItems[index], [field]: value };
      
      // Validação de estoque na edição direta
      if (field === "quantidade") {
        const originalProd = produtos.find(p => p.id === item.produto_id);
        if (originalProd && value > originalProd.estoque) {
            alert("Quantidade excede o estoque!");
            return prev;
        }
      }

      item.subtotal = (item.preco_unitario * item.quantidade) - item.desconto;
      newItems[index] = item;
      return { ...prev, items: newItems };
    });
  };

  const removeItem = (index: number) => {
    setFormData(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== index) }));
  };

  // --- Envio ---
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.cliente_id === 0 || formData.items.length === 0) {
      setError("Selecione um cliente e adicione ao menos um produto.");
      return;
    }

    setLoading(prev => ({ ...prev, submit: true }));
    setError("");

    try {
      const payload = {
        ...formData,
        items: formData.items.map(it => ({
          produto_id: it.produto_id,
          quantidade: it.quantidade,
          preco_unitario: it.preco_unitario,
          desconto: it.desconto
        }))
      };

      const res = isEditMode ? await api.put(`/vendas/${vendaId}`, payload) : await api.post("/vendas", payload);

      if (res.data.success) {
        setSuccess("Venda salva com sucesso!");
        setTimeout(() => navigate("/vendas"), 1500);
      }
    } catch (err: any) {
      setError(err.response?.data?.error || "Erro ao salvar venda.");
    } finally {
      setLoading(prev => ({ ...prev, submit: false }));
    }
  };

  if (loading.initial) return <div className="p-5 text-center">Carregando...</div>;

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between mb-4">
        <h1>{isEditMode ? `Editar Venda #${vendaId}` : "Nova Venda"}</h1>
        <button className="btn btn-secondary" onClick={() => navigate("/vendas")}>Voltar</button>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-8">
            {/* Seção Cliente */}
            <div className="card mb-3">
              <div className="card-body row">
                <div className="col-md-8">
                  <label className="form-label">Cliente</label>
                  <select 
                    className="form-select" 
                    value={formData.cliente_id} 
                    onChange={e => setFormData({...formData, cliente_id: Number(e.target.value)})}
                    disabled={isEditMode}
                    required
                  >
                    <option value={0}>Selecione...</option>
                    {clientes.map(c => <option key={c.id} value={c.id}>{c.nome} ({c.documento})</option>)}
                  </select>
                </div>
                <div className="col-md-4">
                  <label className="form-label">Status</label>
                  <select 
                    className="form-select" 
                    value={formData.status} 
                    onChange={e => setFormData({...formData, status: e.target.value as any})}
                  >
                    <option value="aberta">Aberta</option>
                    <option value="concluida">Concluída</option>
                    <option value="cancelada">Cancelada</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Tabela de Itens */}
            <div className="card">
              <div className="card-header d-flex justify-content-between align-items-center">
                <h5 className="mb-0">Produtos</h5>
                <button type="button" className="btn btn-primary btn-sm" onClick={() => setShowProdutoModal(true)}>
                  + Adicionar Produto
                </button>
              </div>
              <div className="card-body p-0">
                <table className="table table-hover mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Produto</th>
                      <th style={{ width: '120px' }}>Qtd</th>
                      <th>Preço</th>
                      <th style={{ width: '130px' }}>Desconto (R$)</th>
                      <th>Subtotal</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {formData.items.map((item, index) => (
                      <tr key={index}>
                        <td>{item.produto_nome}</td>
                        <td>
                          <input 
                            type="number" className="form-control form-control-sm" 
                            value={item.quantidade} 
                            onChange={e => updateItem(index, "quantidade", Number(e.target.value))}
                            min="1"
                          />
                        </td>
                        <td>{formatCurrency(item.preco_unitario)}</td>
                        <td>
                          <input 
                            type="number" className="form-control form-control-sm" 
                            value={item.desconto} 
                            onChange={e => updateItem(index, "desconto", Number(e.target.value))}
                            min="0"
                            step="0.01"
                          />
                        </td>
                        <td>{formatCurrency(item.subtotal || 0)}</td>
                        <td>
                          <button type="button" className="btn btn-link text-danger p-0" onClick={() => removeItem(index)}>Excluir</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Resumo Lateral */}
          <div className="col-md-4">
            <div className="card sticky-top" style={{ top: '20px' }}>
              <div className="card-header"><h5>Resumo</h5></div>
              <div className="card-body">
                <div className="d-flex justify-content-between mb-2">
                  <span>Bruto:</span><span>{formatCurrency(totals.bruto)}</span>
                </div>
                <div className="d-flex justify-content-between mb-2 text-danger">
                  <span>Descontos:</span><span>-{formatCurrency(totals.desc)}</span>
                </div>
                <hr />
                <div className="d-flex justify-content-between mb-4 fs-5 fw-bold">
                  <span>Total:</span><span className="text-success">{formatCurrency(totals.liquido)}</span>
                </div>
                <button 
                  type="submit" 
                  className="btn btn-success w-100 btn-lg" 
                  disabled={loading.submit || formData.items.length === 0}
                >
                  {loading.submit ? "Processando..." : "Finalizar Venda"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>

      {/* Modal de Seleção */}
      {showProdutoModal && (
        <div className="modal show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Adicionar Produto</h5>
                <button className="btn-close" onClick={() => setShowProdutoModal(false)}></button>
              </div>
              <div className="modal-body">
                {!selectedProduto ? (
                  <>
                    <input 
                      type="text" className="form-control mb-3" 
                      placeholder="Filtrar por nome ou SKU..." 
                      value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                    />
                    <div className="list-group overflow-auto" style={{ maxHeight: '300px' }}>
                      {produtosFiltrados.map(p => (
                        <button 
                          key={p.id} className="list-group-item list-group-item-action d-flex justify-content-between"
                          onClick={() => setSelectedProduto(p)}
                          disabled={p.estoque <= 0}
                        >
                          <span>{p.nome} <small className="text-muted">({p.sku})</small></span>
                          <span>{formatCurrency(p.preco)} | Est: {p.estoque}</span>
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="row">
                    <div className="col-12 mb-3"><h6>{selectedProduto.nome}</h6></div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Quantidade</label>
                      <input 
                        type="number" className="form-control" 
                        value={inputQuantidade} onChange={e => setInputQuantidade(Number(e.target.value))}
                        min="1" max={selectedProduto.estoque}
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Desconto (R$)</label>
                      <input 
                        type="number" className="form-control" 
                        value={inputDesconto} step="0.01" onChange={e => setInputDesconto(Number(e.target.value))}
                        min="0"
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                {selectedProduto && (
                  <button className="btn btn-primary" onClick={addProdutoToVenda}>Adicionar</button>
                )}
                <button className="btn btn-secondary" onClick={() => { setSelectedProduto(null); setShowProdutoModal(false); }}>Fechar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendaForm;