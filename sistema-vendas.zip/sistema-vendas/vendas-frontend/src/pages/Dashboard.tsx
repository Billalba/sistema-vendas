import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api, { isAxiosError } from '../services/api';
import { FaSync , FaPlus, FaTachometerAlt  } from 'react-icons/fa';

interface DashboardStats {
  total_vendas: number;
  vendas_concluidas: number;
  total_clientes: number;
  total_produtos: number;
  receita_total: number;
  ticket_medio: number;
}

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadDashboard = async () => {
    try {
      setLoading(true);
      setError("");
      const response = await api.get("/dashboard/stats");
      const data = response.data; // data = { success: true, data: {...} }
      if (data.success) {
        setStats(data.data);
      } else {
        // Caso a API retorne { success: false } mas com status 200 OK
        setError(data.error || "Erro ao carregar dashboard");
      }
    } catch (err: any) {
      if (isAxiosError(err)) {
        // Erro da API (ex: 404, 500)
        if (err.response && err.response.data && err.response.data.error) {
          // Se o backend mandou uma mensagem de erro específica
          setError(err.response.data.error);
        } else {
          // Mensagem genérica do axios
          setError(`Erro de API: ${err.message}`);
        }
      } else {
        // Erro de rede ou outro erro de JavaScript
        setError("Erro de conexão. Verifique se o backend está rodando.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  };

  if (loading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Carregando...</span>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1><FaTachometerAlt  />  Dashboard</h1>
          <p className="text-muted">Estatísticas em tempo real do sistema</p>
        </div>
        <div>
          <button className="btn btn-outline-secondary me-2" onClick={loadDashboard}>
            <FaSync /> Atualizar
          </button>
          <button className="btn btn-primary" onClick={() => navigate("/vendas/nova")}>
          <FaPlus /> Nova Venda
          </button>
        </div>
      </div>

      {error && (
        <div className="alert alert-warning" role="alert">
          {error}
          <div className="mt-2">
            <button className="btn btn-outline-primary btn-sm" onClick={loadDashboard}>
              🔄 Tentar Novamente
            </button>
          </div>
        </div>
      )}

      {stats && (
        <>
          {/* Cards de Estatísticas */}
          <div className="row mb-4">
            <div className="col-md-3 mb-3">
              <div className="card h-100 border-primary">
                <div className="card-body text-center">
                  <h5 className="card-title">Receita Total</h5>
                  <p className="card-text fs-4 text-success">
                    <strong>{formatCurrency(stats.receita_total)}</strong>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-3 mb-3">
              <div className="card h-100 border-success">
                <div className="card-body text-center">
                  <h5 className="card-title">Vendas Concluídas</h5>
                  <p className="card-text fs-4">
                    <strong>{stats.vendas_concluidas}</strong>
                    <small className="text-muted d-block">de {stats.total_vendas} total</small>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-3 mb-3">
              <div className="card h-100 border-info">
                <div className="card-body text-center">
                  <div className="fs-2"></div>
                  <h5 className="card-title">Total Clientes</h5>
                  <p className="card-text fs-4">
                    <strong>{stats.total_clientes}</strong>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-3 mb-3">
              <div className="card h-100 border-warning">
                <div className="card-body text-center">
                  <h5 className="card-title">Ticket Médio</h5>
                  <p className="card-text fs-4">
                    <strong>{formatCurrency(stats.ticket_medio)}</strong>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Informações Adicionais */}
          <div className="row">
            <div className="col-md-6">
              <div className="card">
                <div className="card-header">
                  <h5 className="mb-0"> Estatísticas de Vendas</h5>
                </div>
                <div className="card-body">
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Total de Vendas</span>
                      <span className="badge bg-primary rounded-pill">{stats.total_vendas}</span>
                    </li>
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Vendas Concluídas</span>
                      <span className="badge bg-success rounded-pill">{stats.vendas_concluidas}</span>
                    </li>
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Taxa de Conclusão</span>
                      <span className="badge bg-info rounded-pill">{stats.total_vendas > 0 ? `${((stats.vendas_concluidas / stats.total_vendas) * 100).toFixed(1)}%` : "0%"}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div className="card">
                <div className="card-header">
                  <h5 className="mb-0"> Resumo do Sistema</h5>
                </div>
                <div className="card-body">
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Total de Produtos</span>
                      <span className="badge bg-secondary rounded-pill">{stats.total_produtos}</span>
                    </li>
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Receita Total</span>
                      <span className="badge bg-success rounded-pill">{formatCurrency(stats.receita_total)}</span>
                    </li>
                    <li className="list-group-item d-flex justify-content-between align-items-center">
                      <span>Ticket Médio</span>
                      <span className="badge bg-warning rounded-pill">{formatCurrency(stats.ticket_medio)}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Mensagem de Status */}
      <div className="row mt-4 pb-5">
        <div className="col">
          <div className="card bg-light">
            <div className="card-body text-center">
              <p className="mb-0">
                {stats ? (
                  <>
                    O sistema está operacional com <strong>{stats.total_clientes} clientes</strong>,<strong> {stats.total_produtos} produtos</strong> e<strong> {stats.total_vendas} vendas</strong> processadas.
                  </>
                ) : (
                  "Conectado ao banco de dados e API funcionando."
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
