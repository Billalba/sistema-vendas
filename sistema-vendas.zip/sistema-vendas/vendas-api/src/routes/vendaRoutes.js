import express from 'express';
import { VendaController } from '../controllers/vendaController.js';

const router = express.Router();

// POST /api/Vendas - Criar nova venda
router.post('/', VendaController.createVenda);

// GET /api/Vendas - Listar vendas com filtros
router.get('/', VendaController.getVendas);

// GET /api/Vendas/:id - Obter detalhes de uma venda
router.get('/:id', VendaController.getVendaById);

// NOVO: Rota para ATUALIZAR uma venda inteira (MÉTODO PUT)
router.put('/:id', VendaController.updateVenda);

// PATCH /api/Vendas/:id/status - Atualizar status da venda
router.patch('/:id/status', VendaController.updateVendaStatus);

export default router;