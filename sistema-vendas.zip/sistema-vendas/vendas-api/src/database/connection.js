import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

// Configuração do pool de conexões (REMOVENDO opções inválidas)
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  connectionLimit: 10,
  // REMOVIDO: acquireTimeout, timeout, reconnect (não são suportados pelo mysql2)
});

// Testar a conexão do pool
async function testPoolConnection() {
  let connection;
  try {
    connection = await pool.getConnection();
    console.log('Pool de conexões configurado com sucesso!');
    return true;
  } catch (error) {
    console.error('Erro no pool de conexões:', error.message);
    return false;
  } finally {
    if (connection) connection.release();
  }
}

// Exportar o pool e função de teste
export { pool, testPoolConnection };
export default pool;