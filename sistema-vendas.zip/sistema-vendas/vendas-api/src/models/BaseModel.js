import { pool } from '../database/connection.js';

export class BaseModel {
  static tableName = '';

  // Método para executar queries
  static async query(sql, params = []) {
    let connection;
    try {
      connection = await pool.getConnection();
      const [results] = await connection.execute(sql, params);
      return results;
    } catch (error) {
      console.error(`Erro na query [${this.tableName}]:`, error.message);
      console.error('SQL:', sql);
      console.error('Params:', params);
      throw error;
    } finally {
      if (connection) connection.release();
    }
  }

  // Buscar por ID
  static async findById(id) {
    const results = await this.query(
      `SELECT * FROM ${this.tableName} WHERE id = ?`,
      [id]
    );
    return results[0] || null;
  }

  // Listar todos (com paginação)
  static async findAll(page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    
    const results = await this.query(
      `SELECT * FROM ${this.tableName} LIMIT ? OFFSET ?`,
      [limit, offset]
    );
    
    // Contar total de registros
    const [countResult] = await this.query(
      `SELECT COUNT(*) as total FROM ${this.tableName}`
    );
    
    return {
      data: results,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult.total,
        totalPages: Math.ceil(countResult.total / limit)
      }
    };
  }
}