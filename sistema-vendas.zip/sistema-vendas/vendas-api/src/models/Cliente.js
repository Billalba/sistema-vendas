import { BaseModel } from './BaseModel.js';

export class Cliente extends BaseModel {
  static tableName = 'clientes';

  // Buscar clientes com filtro
  static async search(searchTerm = '', page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    
    let whereClause = '';
    let whereParams = [];
    
    if (searchTerm) {
      whereClause = 'WHERE (nome LIKE ? OR documento LIKE ? OR email LIKE ?)';
      whereParams = [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`];
    }
    
    const sql = `
      SELECT id, nome, documento, email, telefone, created_at 
      FROM ${this.tableName} 
      ${whereClause}
      ORDER BY nome 
      LIMIT ? OFFSET ?
    `;

    const countSql = `
      SELECT COUNT(*) as total FROM ${this.tableName} 
      ${whereClause}
    `;

    const [clientes, countResult] = await Promise.all([
      this.query(sql, [...whereParams, limit, offset]),
      this.query(countSql, whereParams)
    ]);

    return {
      data: clientes,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total,
        totalPages: Math.ceil(countResult[0].total / limit)
      }
    };
  }

  // Buscar por documento
  static async findByDocument(document) {
    const results = await this.query(
      `SELECT * FROM ${this.tableName} WHERE documento = ?`,
      [document]
    );
    return results[0] || null;
  }
}