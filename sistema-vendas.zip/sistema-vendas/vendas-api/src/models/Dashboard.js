import { BaseModel } from './BaseModel.js';

export class Dashboard extends BaseModel {
  
  // Estatísticas gerais
  static async getGeneralStats() {
    const sql = `
      SELECT 
        -- Total de vendas
        (SELECT COUNT(*) FROM vendas) as total_vendas,
        
        -- Total de vendas concluídas
        (SELECT COUNT(*) FROM vendas WHERE status = 'concluida') as vendas_concluidas,
        
        -- Total de clientes
        (SELECT COUNT(*) FROM clientes) as total_clientes,
        
        -- Total de produtos
        (SELECT COUNT(*) FROM produtos) as total_produtos,
        
        -- Receita total (apenas vendas concluídas)
        (SELECT COALESCE(SUM(total_liquido), 0) FROM vendas WHERE status = 'concluida') as receita_total,
        
        -- Ticket médio
        (SELECT COALESCE(AVG(total_liquido), 0) FROM vendas WHERE status = 'concluida') as ticket_medio
    `;

    const results = await this.query(sql);
    return results[0];
  }

  // Vendas por período (últimos 7 dias)
  static async getVendasByPeriod(days = 7) {
    const sql = `
      SELECT 
        DATE(data_hora) as data,
        COUNT(*) as quantidade_vendas,
        COALESCE(SUM(total_liquido), 0) as receita_dia
      FROM vendas 
      WHERE data_hora >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        AND status = 'concluida'
      GROUP BY DATE(data_hora)
      ORDER BY data DESC
    `;

    return await this.query(sql, [days]);
  }

  // Produtos mais vendidos
  static async getTopProdutos(limit = 5) {
    const sql = `
      SELECT 
        p.id,
        p.nome,
        p.sku,
        SUM(vi.quantidade) as quantidade_vendida,
        SUM(vi.subtotal) as receita_total
      FROM produtos p
      INNER JOIN venda_itens vi ON p.id = vi.produto_id
      INNER JOIN vendas v ON vi.venda_id = v.id
      WHERE v.status = 'concluida'
      GROUP BY p.id, p.nome, p.sku
      ORDER BY quantidade_vendida DESC
      LIMIT ?
    `;

    return await this.query(sql, [limit]);
  }

  // Vendas por status
  static async getVendasByStatus() {
    const sql = `
      SELECT 
        status,
        COUNT(*) as quantidade,
        COALESCE(SUM(total_liquido), 0) as valor_total
      FROM vendas 
      GROUP BY status
      ORDER BY quantidade DESC
    `;

    return await this.query(sql);
  }

  // Clientes que mais compram
  static async getTopClientes(limit = 5) {
    const sql = `
      SELECT 
        c.id,
        c.nome,
        c.documento,
        COUNT(v.id) as total_compras,
        COALESCE(SUM(v.total_liquido), 0) as valor_total_gasto
      FROM clientes c
      LEFT JOIN vendas v ON c.id = v.cliente_id AND v.status = 'concluida'
      GROUP BY c.id, c.nome, c.documento
      ORDER BY valor_total_gasto DESC
      LIMIT ?
    `;

    return await this.query(sql, [limit]);
  }
}