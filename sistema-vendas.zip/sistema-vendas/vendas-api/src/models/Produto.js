import { BaseModel } from './BaseModel.js';

export class Produto extends BaseModel {
  static tableName = 'produtos';

  // Buscar produtos com filtro e paginação
  static async search(searchTerm = '', page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    
    let whereClause = '';
    let whereParams = [];
    
    if (searchTerm) {
      whereClause = 'WHERE (nome LIKE ? OR sku LIKE ? OR descricao LIKE ?)';
      whereParams = [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`];
    }
    
    const sql = `
      SELECT * FROM ${this.tableName} 
      ${whereClause}
      ORDER BY nome 
      LIMIT ? OFFSET ?
    `;

    const countSql = `
      SELECT COUNT(*) as total FROM ${this.tableName} 
      ${whereClause}
    `;

    const [Produtos, countResult] = await Promise.all([
      this.query(sql, [...whereParams, limit, offset]),
      this.query(countSql, whereParams)
    ]);

    return {
      data: Produtos,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total,
        totalPages: Math.ceil(countResult[0].total / limit)
      }
    };
  }

  // Buscar por SKU
  static async findBySku(sku) {
    const results = await this.query(
      `SELECT * FROM ${this.tableName} WHERE sku = ?`,
      [sku]
    );
    return results[0] || null;
  }

  // Atualizar estoque
  static async updateStock(ProdutoId, quantity) {
    await this.query(
      `UPDATE ${this.tableName} SET estoque = estoque - ? WHERE id = ? AND estoque >= ?`,
      [quantity, ProdutoId, quantity]
    );
  }

  // Produtos mais vendidos (para dashboard)
  static async getTopSelling(limit = 5) {
    const sql = `
      SELECT 
        p.id,
        p.nome,
        p.sku,
        SUM(vi.quantidade) as total_vendido,
        SUM(vi.subtotal) as total_receita
      FROM produtos p
      INNER JOIN venda_itens vi ON p.id = vi.produto_id
      INNER JOIN vendas v ON vi.venda_id = v.id
      WHERE v.status = 'concluida'
      GROUP BY p.id, p.nome, p.sku
      ORDER BY total_vendido DESC
      LIMIT ?
    `;

    return await this.query(sql, [limit]);
  }
}