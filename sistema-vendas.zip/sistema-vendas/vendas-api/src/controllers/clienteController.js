import { Cliente } from '../models/Cliente.js';

export class ClienteController {
  // Listar clientes com busca e paginação
  static async getClientes(req, res) {
    try {
      const { search, page = 1, limit = 10 } = req.query;
      
      const result = await Cliente.search(search, parseInt(page), parseInt(limit));
      
      res.json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
      
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar clientes',
        message: error.message
      });
    }
  }

  // Obter detalhes de um cliente
  static async getClienteById(req, res) {
    try {
      const { id } = req.params;
      
      const cliente = await Cliente.findById(parseInt(id));
      
      if (!cliente) {
        return res.status(404).json({
          success: false,
          error: 'Cliente não encontrado'
        });
      }
      
      res.json({
        success: true,
        data: cliente
      });
      
    } catch (error) {
      console.error('Erro ao buscar cliente:', error);
      res.status(500).json({
        success: false,
        error: 'Erro interno ao buscar cliente',
        message: error.message
      });
    }
  }
}